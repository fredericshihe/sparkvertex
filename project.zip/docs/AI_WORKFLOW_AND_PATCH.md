# AI Workflow 与 Patch 完整链路详解

## 📋 目录
1. [AI Workflow 完整链路](#ai-workflow-完整链路)
2. [Patch 系统完整链路](#patch-系统完整链路)

---

## AI Workflow 完整链路

### 🎯 整体架构图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              用户发送修改请求                                      │
│                     "把按钮颜色改成红色" / "修复登录Bug"                            │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Stage 1: Intent Classification (意图分类)                                       │
│  ├── 入口: app/api/generate/route.ts → classifyUserIntent()                     │
│  ├── 核心: lib/intent-classifier.ts → classifyIntentWithDeepSeek()              │
│  └── 输出: intent, targets[], referenceTargets[], reasoning                     │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Stage 2: Code RAG (代码检索增强生成)                                             │
│  ├── 入口: app/api/generate/route.ts → findRelevantCodeChunks()                 │
│  ├── 核心: lib/code-rag.ts → chunkCode() + embedding similarity                 │
│  └── 输出: relevantChunks[] (与用户请求最相关的代码片段)                           │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Stage 3: Smart Compression (智能压缩)                                           │
│  ├── 入口: app/api/generate/route.ts → compressCode()                           │
│  ├── 核心: lib/code-rag.ts → AST Skeletonization / Brutal Truncate              │
│  └── 输出: compressedCode (压缩后的代码上下文, ~60% 压缩率)                        │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Stage 4: LLM Generation (代码生成)                                              │
│  ├── 入口: Supabase Edge Function / 外部 LLM API                                │
│  ├── 输入: compressedCode + ragContext + userPrompt + System Prompt              │
│  └── 输出: <<<<SEARCH ... ==== REPLACE ... >>>> 格式的 Patch                     │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Stage 5: Patch Application (补丁应用)                                           │
│  ├── 入口: app/create/page.tsx → applyPatches()                                 │
│  ├── 核心: lib/patch.ts → Multi-strategy Token/AST Matching                     │
│  └── 输出: 修改后的完整源代码                                                      │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

### Stage 1: Intent Classification (意图分类)

**文件位置**: `lib/intent-classifier.ts`

**核心函数**: `classifyUserIntent()` → `classifyIntentWithDeepSeek()`

**流程**:
```
1. 接收用户 Prompt + 代码文件摘要 (fileSummaries)
                    │
                    ▼
2. 生成文件摘要 (generateFileSummary)
   - 提取每个组件的 useState, useEffect, handlers, 依赖关系
   - 示例: "MapScreen: uses [position, exploredTiles], effects: [player movement], handlers: [handleMove]"
                    │
                    ▼
3. 构建 DeepSeek Prompt
   - 角色: Senior Software Architect
   - 任务: 分析 files_to_edit (需要修改) vs files_to_read (只读参考)
   - 输出格式:
     {
       "reasoning": "用户要求...",
       "intent": "UI_MODIFICATION | LOGIC_FIX | NEW_FEATURE | ...",
       "files_to_edit": ["MapScreen", "BattleScene"],
       "files_to_read": ["CONSTANTS", "Types"]
     }
                    │
                    ▼
4. 调用 Supabase Edge Function → DeepSeek API
   - 超时: 45s
   - 温度: 0.3 (偏保守)
   - Fallback: Gemini 2.5 Flash → 本地规则
                    │
                    ▼
5. 解析响应
   - 提取 JSON (支持 Markdown 代码块包裹)
   - 验证 intent 是否为有效枚举值
   - 从 reasoning 中提取遗漏的文件名 (Safety Net)
```

**意图类型 (UserIntent Enum)**:
| Intent | 描述 | 压缩阈值 |
|--------|------|----------|
| `UI_MODIFICATION` | 颜色、样式、布局 | 8 行 (最激进) |
| `LOGIC_FIX` | Bug 修复、数据流 | 12 行 |
| `NEW_FEATURE` | 新增页面/组件 | 15 行 (最保守) |
| `DATA_OPERATION` | 数据库、API | 12 行 |
| `REFACTOR` | 代码重构 | 10 行 |
| `PERFORMANCE` | 性能优化 | 12 行 |
| `GLOBAL_REVIEW` | 全局检查 | 特殊处理 |

---

### Stage 2: Code RAG (代码检索增强)

**文件位置**: `lib/code-rag.ts`

**核心函数**: `findRelevantCodeChunks()`

**流程**:
```
1. 代码分块 (chunkCode)
   - 按 const/function/class/export 分割
   - 识别 React 组件、常量、工具函数
   - 每个 Chunk 带有: { id, content, type, dependencies }
                    │
                    ▼
2. 向量嵌入 (Embedding)
   - 对用户 Prompt 生成向量
   - 对每个 Chunk 生成向量 (缓存优化)
                    │
                    ▼
3. 相似度评分 (Cosine Similarity)
   - 计算 Prompt 与每个 Chunk 的相似度
   - 示例: MapScreen=0.715, BattleScene=0.742
                    │
                    ▼
4. 智能选择 🆕 STRICT MODE
   - 基础: 相似度 > 0.55 的 Chunks
   - 优先级:
     a) Explicit Targets (Intent 指定的 files_to_edit) → 全量保留
     b) Reference Targets (files_to_read) → 骨架化
     c) 🆕 STRICT MODE: 当 DeepSeek 返回了 targets 时，禁用 "mentioned in prompt" 模糊匹配
     d) Dependencies (被依赖的) → 递归展开
   - 限制: Max 11 Chunks (防止上下文溢出)
                    │
                    ▼
5. 依赖图扩展
   - 如果选中 MapScreen, 自动包含其依赖: TILE_CLASSES, VISIBILITY_RADIUS
   - 优先队列: Explicit Targets 的依赖 > 其他
```

**🆕 P0 优化: STRICT MODE (信任 DeepSeek)**
```typescript
// 当 DeepSeek 提供了 files_to_edit/files_to_read 时
// 完全信任 DeepSeek，禁用基于字符串的模糊匹配
// 防止 "screen" 匹配 "LaunchScreen", "DexScreen" 等噪音

const TRUST_DEEPSEEK_ONLY = explicitTargets.length > 0 || referenceTargets.length > 0;

if (TRUST_DEEPSEEK_ONLY) {
    // 只允许精确匹配完整组件名
    // 禁用中文关键词模糊匹配
}
```

**函数名→父文件解析** (新增修复):
```typescript
// 如果 DeepSeek 返回函数名 "handleMove" 而不是组件名 "MapScreen"
// 系统会自动解析: handleMove → 定义在 MapScreen → 保留 MapScreen 完整代码
```

---

### Stage 3: Smart Compression (智能压缩)

**文件位置**: `lib/code-rag.ts`

**核心函数**: `compressCode()` → `skeletonizeCode()`

**压缩策略分层**:

```
┌─────────────────────────────────────────────────────────────────┐
│  Layer 1: Primary Targets (Explicit Files to Edit)              │
│  策略: 📝 FULL CODE - 完整保留，不做任何压缩                      │
│  示例: MapScreen (用户指定要修改的组件)                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Layer 2: Context References (files_to_read)                    │
│  策略: 📖 AST Skeleton - 保留函数签名，隐藏函数体                 │
│  示例:                                                          │
│    // Before:                                                   │
│    function BattleScene({ player, enemy }) {                    │
│      const [hp, setHp] = useState(100);                         │
│      // ... 260 lines ...                                       │
│      return <div>...</div>                                      │
│    }                                                            │
│    // After:                                                    │
│    function BattleScene({ player, enemy }) {                    │
│      /* Body hidden: 45 statements */                           │
│    }                                                            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  🆕 Layer 3: Data/Config Files (Pure Constants)                 │
│  策略: 📊 Data Skeletonization - 保留所有 KEY，截断长 VALUE      │
│  🆕 P0 优化: 不再使用 Brutal Truncate！                          │
│  示例:                                                          │
│    // Before: VISIBILITY_RADIUS (131 lines)                     │
│    export const VISIBILITY_RADIUS = 3;                          │
│    export const MAP_WIDTH = 20;                                 │
│    export const LARGE_ARRAY = [/* 100 items */];                │
│                                                                 │
│    // After: 保留所有导出的 KEY 名称！                            │
│    export const VISIBILITY_RADIUS = 3;                          │
│    export const MAP_WIDTH = 20;                                 │
│    export const LARGE_ARRAY = [ /* 100 items - see source */ ]; │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Layer 4: Irrelevant Modules (Non-data, Non-target)             │
│  策略: 🗜️ Brutal Truncate - 只保留前 10-15 行                    │
│  适用: 非数据文件的不相关代码 (如 ShopScreen 在修改 MapScreen 时)│
└─────────────────────────────────────────────────────────────────┘
```

**🆕 P0 优化: Data Skeletonization (数据骨架化)**
```typescript
// 检测纯数据文件 (只有 const exports, 没有函数)
// 保留所有导出的变量名，只截断长值

function dataSkeletonize(code: string, chunkId: string) {
    // 1. 检测: 有 exports，无 functions
    const isPureDataFile = /export\s+const/.test(code) && 
                          !/function\s+\w+/.test(code);
    
    // 2. 遍历所有 const 声明
    // 3. 短值 (<300 chars) → 完整保留
    // 4. 长值 (数组/对象) → 保留结构 + "N items truncated"
}
```

**AST Skeletonization 算法**:
```typescript
// 使用 Babel Parser 解析 → traverse → 替换函数体
traverse(ast, {
    "FunctionDeclaration|ArrowFunctionExpression"(path) {
        if (bodySize > 100 || statements > 3) {
            path.get("body").replaceWith(
                t.blockStatement([]) // 空函数体
            );
            // 添加注释: /* Body hidden: 45 statements */
        }
    }
});
```

---

### Stage 4: LLM Generation (代码生成)

**输入构建**:
```
System Prompt (lib/prompts.ts):
├── 角色定义: Expert React Developer
├── 输出格式: <<<<SEARCH ... ==== REPLACE ... >>>>
├── 规则:
│   ├── 不要假设代码存在，使用提供的上下文
│   ├── 每个 Patch 块要包含足够的上下文
│   └── 不要添加不存在的注释

User Prompt:
├── compressedCode (压缩后的完整代码)
├── ragContext (RAG 选中的代码片段)
├── codeContext (优化提示)
└── 用户原始请求
```

**输出格式**:
```diff
<<<<SEARCH
const MapScreen = ({ player, onMove }) => {
    const [position, setPosition] = useState({ x: 5, y: 5 });
====
const MapScreen = ({ player, onMove }) => {
    const [position, setPosition] = useState({ x: 5, y: 5 });
    const [fogOfWar, setFogOfWar] = useState(true); // 新增
>>>>
```

---

## Patch 系统完整链路

### 🎯 整体架构图

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           LLM 输出的 Patch 文本                                  │
│         <<<<SEARCH ... ==== REPLACE ... >>>>  或  <<<<AST_REPLACE: Name>>>>     │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Step 0: Patch 格式检测                                                          │
│  ├── AST_REPLACE 格式 → 走 Explicit AST 路径                                    │
│  └── SEARCH/REPLACE 格式 → 走 Token Matching 路径                               │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
              ┌──────────────────────────┴──────────────────────────┐
              ▼                                                     ▼
┌─────────────────────────────┐                   ┌─────────────────────────────┐
│  Explicit AST Replacement   │                   │  Token-based Matching       │
│  (Scheme 2: Modular)        │                   │  (Scheme 1: Cursor-style)   │
└─────────────────────────────┘                   └─────────────────────────────┘
              │                                                     │
              ▼                                                     ▼
┌─────────────────────────────┐                   ┌─────────────────────────────┐
│  applyExplicitASTPatch()    │                   │  applyPatchesInternal()     │
│  直接定位变量/函数名替换       │                   │  多策略匹配 (见下方详解)      │
└─────────────────────────────┘                   └─────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Post-Validation (安全校验)                                                      │
│  ├── 长度检查: 结果不能太短 (<50% 原始) 或太长 (>300%)                            │
│  ├── 语法修复: validateAndFixSyntax() - 修复常见语法错误                         │
│  ├── 定义去重: dedupeTopLevelBindings() - 删除重复的变量/函数定义                 │
│  ├── 引用检测: detectUndefinedReferences() - 检测删除了但仍被引用的组件            │
│  └── 回滚机制: 任何校验失败 → 返回原始代码                                        │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

### Token Matching 多策略瀑布 (核心算法)

**文件位置**: `lib/patch.ts`

**核心函数**: `applyPatchesInternal()`

**🆕 Token Normalization (P2 优化)**

在所有 Token 匹配策略执行前，首先对 Token 进行归一化处理，消除因引号风格、可选分号等导致的虚假不匹配：

```typescript
/**
 * Token Normalization Rules:
 * 1. 引号归一化: " → ', ` → '  (双引号/模板字符串 统一为 单引号)
 * 2. 分号归一化: 在 JS/TS 中分号是可选的，不应导致匹配失败
 * 
 * 示例场景:
 * - AI 输出: const name = "value"
 * - 源码:   const name = 'value'
 * - 归一化后: 两者 Token 序列相同，匹配成功
 */

interface Token {
    text: string;      // 原始文本
    normalized: string; // 🆕 归一化后文本
    start: number;
    end: number;
}

function normalizeToken(text: string): string {
    // Rule 1: 引号归一化
    if (text === '"' || text === '`') return "'";
    return text;
}

// 比较函数优先使用归一化后的值
function tokensEqual(a: Token, b: Token): boolean {
    if (a.text === b.text) return true; // 快速路径
    return a.normalized === b.normalized; // 归一化比较
}
```

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 0: AST Smart Patch (变量/函数整体替换)                                  │
│  ├── 触发条件: replaceBlock 是完整的 const/function 定义                         │
│  ├── 算法: 解析 replaceBlock AST → 提取变量名 → 在源码中定位同名定义 → 整体替换    │
│  └── 示例: const MONSTERS = [...] 整体替换                                      │
│  ✅ 成功 → 结束 | ❌ 失败 → 继续                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 1: Exact Token Match (精确 Token 匹配)                                 │
│  ├── 算法:                                                                      │
│  │   1. tokenize(searchBlock) → ['const', 'x', '=', '1', ';']                  │
│  │   2. tokenize(sourceCode) → [...全部 tokens...]                             │
│  │   3. 滑动窗口: 连续匹配所有 search tokens                                     │
│  ├── 特点: 忽略空格/换行，只比较语义单元                                          │
│  └── 示例: "const  x=1" 可以匹配 "const x = 1"                                  │
│  ✅ 成功 → 结束 | ❌ 失败 → 继续                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 1.5: Comment-Insensitive Match (注释无关匹配) 🆕                       │
│  ├── 触发条件: 精确匹配失败 + searchBlock 包含注释                                │
│  ├── 算法:                                                                      │
│  │   1. stripComments(searchBlock) - 移除所有注释                               │
│  │   2. 用去注释的 tokens 重新进行 Relaxed Match                                │
│  ├── 目的: 解决 AI 幻觉添加注释 (如 {/* Fog of War */}) 的问题                   │
│  └── 示例: AI 输出包含注释，但源码无注释 → 仍然能匹配                              │
│  ✅ 成功 → 结束 | ❌ 失败 → 继续                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 2: Relaxed Token Match (宽松 Token 匹配)                               │
│  ├── 触发条件: relaxedMode = true (上传的代码首次编辑)                            │
│  ├── 算法: LCS (Longest Common Subsequence)                                     │
│  │   - 允许跳过部分 tokens (容忍轻微差异)                                        │
│  │   - 阈值: 匹配率 > 70%                                                       │
│  └── 示例: 源码多了空行或注释，仍能匹配                                           │
│  ✅ 成功 → 结束 | ❌ 失败 → 继续                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 3: AST Lite - Function Body Match (函数体匹配)                         │
│  ├── 算法:                                                                      │
│  │   1. 从 searchBlock 提取函数名 (如 handleMove)                               │
│  │   2. 在源码中定位该函数的完整范围 (start-end)                                  │
│  │   3. 整体替换函数体                                                          │
│  ├── 特点: 不需要精确匹配内容，只需函数名匹配                                      │
│  └── 示例: function handleMove() {...} 整体替换                                 │
│  ✅ 成功 → 结束 | ❌ 失败 → 继续                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Strategy 4: Anchor Matching (锚点匹配)                                          │
│  ├── 触发条件: searchBlock 包含压缩标记 或 其他策略全部失败                        │
│  ├── 算法:                                                                      │
│  │   1. 取 searchBlock 首行 + 末行作为"锚点"                                     │
│  │   2. 在源码中查找: 首行出现位置 → 在其后 500 行内查找末行                       │
│  │   3. 用 [首行位置, 末行位置] 定义替换范围                                      │
│  ├── 特点: 中间内容无关，只关心边界                                               │
│  └── 示例: 首行 "const MapScreen = () => {" + 末行 "};" → 定位整个组件           │
│  ✅ 成功 → 结束 | ❌ 失败 → 抛出错误                                             │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

### Safety Nets (安全网机制)

**Safety Net 1: AST Dedupe (去重)**
```typescript
// 检测并删除重复的顶层定义
// 场景: AI 同时输出了新版本和保留了旧版本
dedupeTopLevelBindings(code);
// 示例: 两个 const MapScreen = ... → 只保留后者
```

**Safety Net 2: Undefined Reference Detection**
```typescript
// 检测删除了定义但仍有引用的情况
detectUndefinedReferences(code);
// 示例: AI 删除了 BattleScene 定义，但 <BattleScene /> 仍存在 → 回滚
```

**Safety Net 3: Incremental Validation**
```typescript
// 每个 Patch 应用后立即校验
validateIncrementalPatch(previousSource, newSource, originalDefinitions, patchIndex);
// 检查:
// - 语法是否合法 (Babel parse)
// - 是否丢失了组件定义
// - 是否产生了孤儿代码 (顶层的 hooks 调用)
```

**Safety Net 4: Target Range Restriction**
```typescript
// 限制 Patch 只能应用到 Intent 指定的文件范围内
allowedRanges = findTargetRanges(source, targets);
// 防止: AI 的 searchBlock 意外匹配到错误的位置
```

**🆕 Safety Net 5: Anchor Uniqueness Check (P1 优化)**
```typescript
// 🆕 P1 优化: 锚点匹配前检查首行是否唯一
const startOccurrences = sourceLines.filter(l => l.trim() === startLine).length;

if (startOccurrences > 1) {
    console.log(`⚠️ Start anchor is not unique (${startOccurrences} occurrences), expanding...`);
    // 扩展锚点: 使用前 2 行组合匹配
    const combinedStart = searchLines[0] + '\n' + searchLines[1];
    // 找到唯一匹配后再继续
}
```

**🆕 Safety Net 6: Transactional Patching (P1 优化)**
```typescript
// 🆕 P1 优化: 事务性 Patch 应用
// 所有 Patch 在 workingSource 副本上执行
// 只有全部成功才返回修改后的代码

let workingSource = source; // 工作副本
const appliedPatches: { index: number; before: string; after: string }[] = [];

// 应用每个 Patch...
appliedPatches.push({ index, before: previousSource, after: workingSource });

// 最终检查
if (failCount > 0 && successCount === 0) {
    throw new Error('无法应用修改'); // 完全失败
}

console.log(`✅ TRANSACTION COMPLETE: ${successCount} patches applied`);
return workingSource;
```

---

### stripComments 实现 (注释剥离)

```typescript
function stripComments(code: string): string {
    return code
        .replace(/\{\/\*[\s\S]*?\*\/\}/g, '') // JSX 注释 {/* ... */} (必须先处理)
        .replace(/\/\*[\s\S]*?\*\//g, '')     // 块注释 /* ... */
        .replace(/\/\/.*/g, '');              // 行注释 // ...
}
```

**为什么 JSX 注释要先处理?**
```jsx
// 错误顺序 (先处理块注释):
{/* comment */}  →  { }  // 留下空大括号，破坏 JSX

// 正确顺序 (先处理 JSX 注释):
{/* comment */}  →  (空)  // 完整删除
```

---

### Patch 失败常见原因

| 错误信息 | 原因 | 解决方案 |
|---------|------|---------|
| `找不到匹配的代码块` | AI 的 SEARCH 块与源码不匹配 | Comment-Insensitive Match (已实现) |
| `Patch 结果过短` | AI 只输出了部分代码 | 长度校验 + 回滚 |
| `重复定义` | AI 没有删除旧代码 | AST Dedupe |
| `未定义引用` | AI 删除了组件但留下了使用 | Undefined Reference Detection |
| `语法错误` | AI 输出了不完整的代码 | validateAndFixSyntax() 自动修复 |
| 🆕 `锚点不唯一` | 多个相同的 useEffect/函数签名 | Anchor Uniqueness Check + 扩展锚点 |

---

## 🆕 优化历史 (Changelog)

### 2025-12-11 P2 优化

**P2 优化 (持续改进)**:
5. **Token Normalization**: Token 归一化提升匹配容错
   - 解决: 引号风格差异 (`"foo"` vs `'foo'`) 导致的虚假不匹配
   - 新函数: `normalizeToken()`, `tokensEqual()`, `tokenTextEqual()`
   - 规则: 双引号/模板字符串 → 单引号归一化
   - 文件: `lib/patch.ts`

### 2025-12-11 P0/P1 优化

**P0 优化 (立即修复)**:
1. **STRICT MODE for RAG**: 当 DeepSeek 返回 targets 时，禁用 "mentioned in prompt" 模糊匹配
   - 解决: "screen" 匹配 "LaunchScreen", "DexScreen" 的噪音问题
   - 文件: `lib/code-rag.ts`

2. **Data Skeletonization**: 纯数据文件不再使用 Brutal Truncate
   - 解决: `VISIBILITY_RADIUS` 等常量被截断丢失值的问题
   - 新函数: `dataSkeletonize()` - 保留所有导出 KEY，只截断长 VALUE
   - 文件: `lib/code-rag.ts`

**P1 优化 (短期)**:
3. **Anchor Uniqueness Check**: 锚点匹配前检查首行唯一性
   - 解决: 多个相同 `useEffect` 导致匹配错位的问题
   - 策略: 首行不唯一时，自动扩展为前 2 行组合匹配
   - 文件: `lib/patch.ts`

4. **Transactional Patching**: 事务性 Patch 应用
   - 解决: 部分 Patch 失败导致代码"半死不活"的问题
   - 策略: 在副本上执行所有 Patch，全部成功才提交
   - 文件: `lib/patch.ts`

---

## 附录: 关键配置

### Babel Parser 配置
```typescript
export const BABEL_PARSER_CONFIG = {
    sourceType: 'module',
    plugins: [
        'jsx', 'typescript', 'decorators-legacy', 
        'classProperties', 'objectRestSpread',
        'optionalChaining', 'nullishCoalescingOperator',
        'dynamicImport', 'exportDefaultFrom'
    ],
    errorRecovery: true
};
```

### Token 化正则 (带归一化)
```typescript
// 基础 Token 提取
const regex = /([a-zA-Z0-9_$]+)|([^\s\w])/g;
// 匹配:
// - 标识符: myVar, useState, $element
// - 符号: {, }, (, ), =, ;, <, >
// 不匹配:
// - 空白字符 (空格, 换行, Tab)

// 🆕 Token 归一化
function normalizeToken(text: string): string {
    if (text === '"' || text === '`') return "'";  // 引号归一化
    return text;
}
```

---

*最后更新: 2025-12-11*
