# SparkVertex (灵枢) - 项目架构文档

## 📋 项目概述

**SparkVertex（灵枢）** 是一个基于 **Local-First** 理念的 AI 驱动应用生成与分发平台。用户可以通过自然语言描述，由 AI 自动生成完整的 Web 应用代码，并支持 PWA 安装、在线预览和社区分享。

---

## 🏗️ 整体架构图

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                                   SparkVertex 系统架构                                │
└─────────────────────────────────────────────────────────────────────────────────────┘

                              ┌──────────────────────┐
                              │     用户端 (Client)   │
                              │  • 浏览器 (Web/PWA)   │
                              │  • Electron 桌面端    │
                              └──────────┬───────────┘
                                         │
                    ┌────────────────────┼────────────────────┐
                    │                    │                    │
                    ▼                    ▼                    ▼
┌─────────────────────────┐ ┌─────────────────────────┐ ┌─────────────────────────┐
│      Next.js 前端        │ │     Next.js API        │ │   Supabase Edge Func    │
│   (React + Tailwind)    │ │    (Route Handlers)    │ │   (Deno Runtime)        │
│                         │ │                         │ │                         │
│  • 页面渲染 (SSR/SSG)    │ │  • /api/generate       │ │  • generate-app         │
│  • 状态管理 (Context)    │ │  • /api/analyze        │ │  • deepseek-chat        │
│  • 国际化 (i18n)         │ │  • /api/payment/*      │ │  • embed                │
│  • PWA 支持             │ │  • /api/cron/*         │ │  • score-items          │
└─────────────┬───────────┘ └─────────────┬───────────┘ └─────────────┬───────────┘
              │                           │                           │
              └───────────────────────────┼───────────────────────────┘
                                          │
                         ┌────────────────┼────────────────┐
                         │                │                │
                         ▼                ▼                ▼
              ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
              │   Supabase DB   │ │  外部 AI 服务    │ │   支付服务       │
              │  (PostgreSQL)   │ │                 │ │                 │
              │                 │ │  • Gemini API   │ │  • 支付宝        │
              │  • items        │ │  • DeepSeek API │ │  • 爱发电        │
              │  • profiles     │ │  • Embeddings   │ │                 │
              │  • orders       │ │                 │ │                 │
              │  • rag_logs     │ │                 │ │                 │
              └─────────────────┘ └─────────────────┘ └─────────────────┘
```

---

## 📁 项目目录结构

```
spark-vertex-next/
├── app/                          # Next.js App Router (页面 & API)
│   ├── layout.tsx                # 根布局 (全局 Provider)
│   ├── page.tsx                  # 首页
│   ├── globals.css               # 全局样式
│   │
│   ├── api/                      # API 路由
│   │   ├── generate/             # AI 代码生成 (核心)
│   │   ├── analyze/              # AI 需求分析
│   │   ├── embed/                # 向量嵌入
│   │   ├── payment/              # 支付相关
│   │   │   ├── create/           # 创建支付订单
│   │   │   ├── notify/           # 支付回调
│   │   │   ├── check-status/     # 查询支付状态
│   │   │   └── afdian/           # 爱发电支付
│   │   ├── cron/                 # 定时任务
│   │   │   ├── cleanup-orders/   # 清理过期订单
│   │   │   ├── health-check/     # 健康检查
│   │   │   └── retry-credits/    # 积分重试
│   │   ├── refund/               # 退款处理
│   │   ├── generate-icon/        # 图标生成
│   │   ├── manifest/[id]/        # 动态 PWA manifest
│   │   └── score-item/           # 作品评分
│   │
│   ├── create/                   # 创作页面 (AI 生成)
│   ├── explore/                  # 灵枢广场 (作品浏览)
│   ├── profile/                  # 个人中心
│   ├── upload/                   # 上传作品
│   ├── p/[id]/                   # 作品详情页
│   ├── preview/                  # 预览页面
│   ├── guide/                    # 开发指南
│   ├── why/                      # 核心理念
│   ├── auth/                     # 认证回调
│   └── update-password/          # 更新密码
│
├── components/                   # React 组件
│   ├── Navbar.tsx                # 导航栏
│   ├── Footer.tsx                # 页脚
│   ├── Hero.tsx                  # 首页 Hero 区域
│   ├── ProjectCard.tsx           # 作品卡片
│   │
│   ├── CreationChat.tsx          # AI 创作对话界面
│   ├── CreationPreview.tsx       # 代码预览组件
│   ├── AIWorkflowProgress.tsx    # AI 工作流进度
│   ├── GenerationProgress.tsx    # 生成进度展示
│   ├── CodeWaterfall.tsx         # 代码瀑布流效果
│   │
│   ├── DetailModal.tsx           # 作品详情弹窗
│   ├── LoginModal.tsx            # 登录弹窗
│   ├── PaymentModal.tsx          # 支付弹窗
│   ├── CreditPurchaseModal.tsx   # 积分充值弹窗
│   ├── ConfirmModal.tsx          # 通用确认弹窗
│   ├── FeedbackModal.tsx         # 反馈弹窗
│   ├── EditProfileModal.tsx      # 编辑资料弹窗
│   ├── RewardModal.tsx           # 打赏弹窗
│   │
│   ├── CityBackground.tsx        # 城市背景动画
│   ├── SkeletonLoader.tsx        # 骨架屏加载
│   ├── Toast.tsx                 # Toast 提示
│   ├── WeChatGuard.tsx           # 微信浏览器检测
│   └── ServiceWorkerRegister.tsx # PWA Service Worker
│
├── context/                      # React Context (状态管理)
│   ├── LanguageContext.tsx       # 国际化语言切换
│   ├── ModalContext.tsx          # 全局弹窗状态
│   └── ToastContext.tsx          # Toast 通知状态
│
├── lib/                          # 工具库 & 核心逻辑
│   ├── supabase.ts               # Supabase 客户端
│   ├── utils.ts                  # 通用工具函数
│   ├── cache.ts                  # 缓存管理
│   │
│   ├── prompts.ts                # AI Prompt 模板
│   ├── ai-analysis.ts            # AI 分析工具
│   ├── intent-classifier.ts      # 用户意图分类器
│   ├── code-rag.ts               # 代码 RAG 检索
│   ├── rag.ts                    # RAG 主逻辑
│   ├── rag-logger.ts             # RAG 日志记录
│   ├── ast-parser.ts             # AST 代码解析
│   ├── patch.ts                  # 代码补丁应用
│   ├── preview.ts                # 预览内容处理
│   │
│   ├── alipay.ts                 # 支付宝 SDK
│   ├── afdian.ts                 # 爱发电 API
│   ├── rate-limit.ts             # 请求限流
│   ├── sha256.ts                 # 签名工具
│   │
│   ├── categories.ts             # 作品分类定义
│   └── i18n/                     # 国际化
│       └── translations.ts       # 中英文翻译
│
├── supabase/                     # Supabase 配置 & 函数
│   ├── config.toml               # Supabase 本地配置
│   ├── migrations/               # 数据库迁移脚本
│   └── functions/                # Edge Functions
│       ├── generate-app/         # AI 代码生成
│       ├── generate-app-async/   # 异步生成
│       ├── deepseek-chat/        # DeepSeek 聊天
│       ├── embed/                # 向量嵌入
│       ├── score-items/          # 作品评分
│       ├── analyze-html/         # HTML 分析
│       ├── daily-recommendation/ # 每日推荐
│       └── send-auth-email/      # 认证邮件
│
├── types/                        # TypeScript 类型定义
│   └── supabase.ts               # 数据库类型
│
├── public/                       # 静态资源
│   ├── manifest.json             # PWA Manifest
│   ├── sw.js                     # Service Worker
│   └── icons/                    # 图标资源
│
├── electron/                     # Electron 桌面端
├── dist-electron/                # Electron 打包输出
│
├── middleware.ts                 # Next.js 中间件
├── next.config.js                # Next.js 配置
├── tailwind.config.ts            # Tailwind CSS 配置
├── tsconfig.json                 # TypeScript 配置
└── vercel.json                   # Vercel 部署配置
```

---

## 🔄 核心业务流程

### 1. AI 代码生成流程

```
┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│  用户输入需求  │───▶│  意图分类     │───▶│  RAG 检索    │───▶│  代码压缩     │
│  (自然语言)   │    │  (DeepSeek)  │    │  (pgvector)  │    │  (AST 解析)  │
└──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
                                                                    │
                                                                    ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│  展示预览     │◀───│  补丁应用     │◀───│  流式输出     │◀───│  Gemini 生成  │
│  (iframe)    │    │  (diff-match) │    │  (SSE)       │    │  (Pro/Flash) │
└──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
```

### 2. 支付流程

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  选择套餐    │───▶│  创建订单    │───▶│  生成支付码  │───▶│  用户扫码支付 │
│  (前端)     │    │  /api/create │    │  (QR Code)  │    │  (支付宝)    │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
                                                                │
                                                                ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  充值成功    │◀───│  增加积分    │◀───│  更新订单    │◀───│  支付回调    │
│  (前端刷新)  │    │  (DB RPC)   │    │  (状态更新)  │    │  /api/notify│
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
```

### 3. 作品发布流程

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  生成代码    │───▶│  发布作品    │───▶│  AI 评分     │───▶│  展示在广场  │
│  (create)   │    │  (DB 写入)  │    │  (score-item)│    │  (explore)  │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
```

---

## 🗄️ 数据库设计 (Supabase PostgreSQL)

### 核心表结构

```
┌─────────────────────────────────────────────────────────────────────┐
│                          profiles (用户表)                           │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 用户 ID (关联 auth.users)                   │
│ username               │ 用户名                                      │
│ avatar_url             │ 头像 URL                                    │
│ bio                    │ 个人简介                                    │
│ payment_qr             │ 收款二维码                                   │
│ credits                │ 积分余额                                    │
│ daily_reward_date      │ 最后领取每日奖励的日期                        │
│ created_at             │ 注册时间                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                           items (作品表)                             │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 作品 ID                                     │
│ title                  │ 标题                                        │
│ description            │ 描述                                        │
│ content                │ HTML 代码内容                               │
│ prompt                 │ 生成时的 Prompt                             │
│ author_id (FK)         │ 作者 ID                                     │
│ category               │ 分类 (game/tool/design...)                  │
│ tags                   │ 标签数组                                    │
│ icon_url               │ 图标 URL                                    │
│ is_public              │ 是否公开                                    │
│ is_draft               │ 是否草稿                                    │
│ views / likes          │ 浏览/点赞数                                 │
│ quality_score          │ AI 质量评分                                 │
│ total_score            │ 综合评分                                    │
│ analysis_reason        │ AI 评分理由                                 │
│ created_at             │ 创建时间                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                       generation_tasks (生成任务表)                   │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 任务 ID                                     │
│ user_id (FK)           │ 用户 ID                                     │
│ prompt                 │ 用户输入的 Prompt                            │
│ status                 │ 状态 (pending/processing/completed/failed)  │
│ result                 │ 生成结果                                    │
│ cost                   │ 消耗积分                                    │
│ model                  │ 使用的模型                                   │
│ error_message          │ 错误信息                                    │
│ created_at             │ 创建时间                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                          orders (订单表)                             │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 订单 ID                                     │
│ buyer_id (FK)          │ 买家 ID                                     │
│ item_id (FK)           │ 作品 ID (可选)                               │
│ amount                 │ 金额                                        │
│ credits                │ 获得积分                                    │
│ status                 │ 状态 (pending/paid/expired)                 │
│ payment_type           │ 支付方式 (alipay/afdian)                    │
│ trade_no               │ 平台交易号                                   │
│ created_at             │ 创建时间                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                       code_embeddings (代码向量表)                    │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 向量 ID                                     │
│ item_id (FK)           │ 关联作品                                    │
│ chunk_id               │ 代码块标识                                   │
│ content                │ 代码内容                                    │
│ embedding (vector 768) │ 向量嵌入 (pgvector)                         │
│ created_at             │ 创建时间                                    │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         rag_logs (RAG 日志表)                        │
├─────────────────────────────────────────────────────────────────────┤
│ id (uuid, PK)          │ 日志 ID                                     │
│ user_id (FK)           │ 用户 ID                                     │
│ user_query             │ 用户查询                                    │
│ detected_intent        │ 检测到的意图                                 │
│ intent_confidence      │ 意图置信度                                   │
│ intent_source          │ 来源 (local/deepseek)                       │
│ intent_latency_ms      │ 意图分类延迟                                 │
│ rag_latency_ms         │ RAG 检索延迟                                │
│ created_at             │ 创建时间                                    │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🧠 AI 系统架构

### 意图分类系统

```
┌─────────────────────────────────────────────────────────────────────┐
│                       Intent Classifier (意图分类器)                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   用户输入 ──▶ 本地关键词匹配 ──┬──▶ 高置信度 (>0.7) ──▶ 直接返回    │
│                               │                                     │
│                               └──▶ 低置信度 ──▶ DeepSeek API ──▶ 返回│
│                                                                     │
│   支持的意图类型:                                                    │
│   • UI_MODIFICATION  - 改颜色、布局、样式                             │
│   • LOGIC_FIX        - 修复 Bug、业务逻辑                            │
│   • CONFIG_HELP      - 环境变量、配置问题                             │
│   • NEW_FEATURE      - 新增功能                                      │
│   • REFACTOR         - 代码重构                                      │
│   • DATA_OPERATION   - 数据库、API 操作                              │
│   • BACKEND_SETUP    - 后端配置                                      │
│   • GLOBAL_REVIEW    - 全局代码审查                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### RAG 检索系统

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Code RAG System                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   1. 代码分块 (chunkCode)                                           │
│      └── AST 解析 → 按组件/函数/常量分块                             │
│                                                                     │
│   2. 向量嵌入 (embedCode)                                           │
│      └── Gemini gemini-embedding-001 → 768 维向量                   │
│                                                                     │
│   3. 相似度搜索 (findRelevantCodeChunks)                            │
│      └── pgvector 余弦相似度 → Top-K 相关代码块                      │
│                                                                     │
│   4. 代码压缩 (compressCode)                                        │
│      └── 移除注释/空行 → 压缩变量名 → 生成摘要                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### AI 模型配置

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Model Configuration                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   Gemini 2.5 Flash ⚡                                               │
│   ├── 用途: 日常修改、简单任务                                        │
│   ├── 速度: 最快                                                     │
│   └── Token/积分: 15000                                             │
│                                                                     │
│   Gemini 2.5 Pro 🚀                                                 │
│   ├── 用途: 复杂任务、默认选项                                        │
│   ├── 速度: 均衡                                                     │
│   └── Token/积分: 4000                                              │
│                                                                     │
│   Gemini 3 Pro 🧠 (Preview)                                         │
│   ├── 用途: 高质量、复杂逻辑                                          │
│   ├── 速度: 较慢                                                     │
│   └── Token/积分: 3000                                              │
│                                                                     │
│   DeepSeek (意图分类专用)                                            │
│   └── 用于低置信度场景下的意图识别增强                                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🌐 前端架构

### 状态管理 (React Context)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Context Providers                           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   LanguageProvider                                                  │
│   ├── language: 'zh' | 'en'                                         │
│   ├── setLanguage()                                                 │
│   └── t: translations[language]                                     │
│                                                                     │
│   ModalProvider                                                     │
│   ├── isLoginModalOpen / openLoginModal / closeLoginModal           │
│   ├── isDetailModalOpen / openDetailModal / closeDetailModal        │
│   ├── isPaymentModalOpen / openPaymentModal / closePaymentModal     │
│   ├── isCreditPurchaseModalOpen / openCreditPurchaseModal           │
│   ├── isConfirmModalOpen / openConfirmModal / closeConfirmModal     │
│   └── ... (其他弹窗状态)                                             │
│                                                                     │
│   ToastProvider                                                     │
│   ├── success(message)                                              │
│   └── error(message)                                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 页面组件关系

```
┌─────────────────────────────────────────────────────────────────────┐
│                         layout.tsx (根布局)                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   ├── LanguageProvider                                              │
│   │   └── ToastProvider                                             │
│   │       └── ModalProvider                                         │
│   │           ├── CityBackground (背景动画)                          │
│   │           ├── Navbar (导航栏)                                    │
│   │           ├── {children} (页面内容)                              │
│   │           ├── Footer (页脚)                                      │
│   │           │                                                     │
│   │           ├── LoginModal                                        │
│   │           ├── DetailModal                                       │
│   │           ├── PaymentModal                                      │
│   │           ├── CreditPurchaseModal                               │
│   │           ├── ConfirmModal                                      │
│   │           └── ... (其他全局弹窗)                                  │
│   │                                                                 │
└───┴─────────────────────────────────────────────────────────────────┘
```

---

## 🔌 API 接口设计

### 代码生成 API

```
POST /api/generate
Headers: Accept: text/event-stream (SSE)

Request:
{
  "type": "modification" | "creation",
  "user_prompt": "用户描述",
  "current_code": "现有代码 (修改时)",
  "model": "gemini-2.5-pro",
  "skip_compression": false
}

SSE Events:
├── { type: "thinking", data: { reasoning, intent, targets } }
├── { type: "progress", data: { stage, message } }
├── { type: "result", data: { code, taskId, cost, summary } }
└── { type: "error", data: { error, message } }
```

### 支付 API

```
POST /api/payment/create
{
  "amount": 9.9,
  "credits": 100,
  "payment_type": "alipay"
}
Response: { order_id, qr_code_url }

POST /api/payment/notify (回调)
支付宝异步通知 → 验签 → 更新订单 → 增加积分

GET /api/payment/check-status?order_id=xxx
Response: { status: "paid" | "pending" | "expired" }
```

---

## 🚀 部署架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Vercel (前端 + API)                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   Next.js Application                                               │
│   ├── Static Pages (SSG): /, /guide, /why                           │
│   ├── Dynamic Pages (SSR): /explore, /p/[id], /profile              │
│   ├── API Routes: /api/*                                            │
│   └── Edge Middleware: middleware.ts                                │
│                                                                     │
│   Cron Jobs (vercel.json):                                          │
│   ├── /api/cron/health-check   (每 5 分钟)                          │
│   ├── /api/cron/cleanup-orders (每小时)                             │
│   └── /api/cron/retry-credits  (每 10 分钟)                         │
│                                                                     │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Supabase (后端服务)                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   PostgreSQL Database                                               │
│   ├── 用户认证 (auth.users)                                         │
│   ├── 业务数据 (public.*)                                           │
│   ├── 向量搜索 (pgvector extension)                                 │
│   └── RLS 行级安全策略                                               │
│                                                                     │
│   Edge Functions (Deno)                                             │
│   ├── generate-app: AI 代码生成                                      │
│   ├── deepseek-chat: DeepSeek API 代理                              │
│   ├── embed: 向量嵌入生成                                            │
│   └── score-items: 作品评分                                          │
│                                                                     │
│   Storage                                                           │
│   ├── avatars: 用户头像                                              │
│   └── icons: 作品图标                                                │
│                                                                     │
│   Realtime                                                          │
│   └── 订单状态/积分变更实时推送                                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔐 安全设计

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Security Layers                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   1. 认证层 (Supabase Auth)                                         │
│      ├── 邮箱/密码登录                                               │
│      ├── 第三方 OAuth (Google/GitHub)                               │
│      └── JWT Token 验证                                             │
│                                                                     │
│   2. API 层                                                         │
│      ├── 请求签名验证 (支付回调)                                      │
│      ├── Rate Limiting (限流)                                       │
│      └── CORS 配置                                                  │
│                                                                     │
│   3. 数据库层 (RLS)                                                 │
│      ├── 用户只能访问自己的数据                                       │
│      ├── 公开作品所有人可见                                          │
│      └── 积分操作仅通过 RPC 函数                                      │
│                                                                     │
│   4. 前端层                                                         │
│      ├── iframe sandbox (预览隔离)                                   │
│      ├── CSP 内容安全策略                                            │
│      └── 敏感信息脱敏                                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📊 技术栈总结

| 层级 | 技术选型 |
|------|----------|
| **前端框架** | Next.js 14 (App Router) |
| **UI 框架** | React 18 + Tailwind CSS |
| **状态管理** | React Context |
| **国际化** | 自研 i18n (translations.ts) |
| **数据库** | Supabase (PostgreSQL + pgvector) |
| **认证** | Supabase Auth |
| **后端函数** | Supabase Edge Functions (Deno) |
| **AI 服务** | Google Gemini API + DeepSeek API |
| **支付** | 支付宝 + 爱发电 |
| **部署** | Vercel (前端) + Supabase (后端) |
| **PWA** | next-pwa + Service Worker |
| **桌面端** | Electron (实验性) |

---

## 📝 版本信息

- **项目名称**: SparkVertex (灵枢)
- **版本**: 0.1.0
- **文档更新**: 2025-12-09
