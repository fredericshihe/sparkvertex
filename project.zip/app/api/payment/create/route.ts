import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { getAlipaySdk } from '@/lib/alipay';

export async function POST(request: Request) {
  try {
    // 1. 验证用户
    const cookieStore = cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) { return cookieStore.get(name)?.value },
          set(name: string, value: string, options: CookieOptions) { cookieStore.set({ name, value, ...options }) },
          remove(name: string, options: CookieOptions) { cookieStore.set({ name, value: '', ...options }) },
        },
      }
    );
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    let { amount, credits } = await request.json();
    
    // 2. 生成唯一订单号
    const outTradeNo = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // 3. 在数据库创建订单 (使用 credit_orders 表以免与现有 orders 表冲突)
    const { error: dbError } = await supabase
      .from('credit_orders')
      .insert({
        user_id: session.user.id,
        out_trade_no: outTradeNo,
        amount: amount,
        credits: credits,
        status: 'pending'
      });

    if (dbError) throw dbError;

    // 4. 调用支付宝接口
    // 使用 pageExec 生成支付链接，不再使用 AlipayFormData
    const result = await getAlipaySdk().pageExec('alipay.trade.wap.pay', {
      method: 'GET',
      bizContent: {
        outTradeNo: outTradeNo,
        productCode: 'QUICK_WAP_WAY',
        totalAmount: amount.toString(),
        subject: `购买 ${credits} 积分`,
        body: 'Spark Vertex 积分充值',
      },
      notifyUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/payment/notify`,
      returnUrl: `${process.env.NEXT_PUBLIC_APP_URL}/profile`,
    });

    return NextResponse.json({ url: result });

  } catch (error: any) {
    console.error('Payment Create Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
